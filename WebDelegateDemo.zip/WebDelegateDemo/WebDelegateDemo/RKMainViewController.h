//
//  RKMainViewController.h
//  WebDelegateDemo
//
//  Copyright (c) 2014 Ram Kulkarni. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WebViewInterface.h"

@interface RKMainViewController : UIViewController <WebViewInterface>
@property (weak, nonatomic) IBOutlet UIWebView *webView;

@end
