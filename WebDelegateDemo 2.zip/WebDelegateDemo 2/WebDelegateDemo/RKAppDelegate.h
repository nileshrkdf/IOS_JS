//
//  RKAppDelegate.h
//  WebDelegateDemo
//
//  Copyright (c) 2014 Ram Kulkarni. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RKAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
